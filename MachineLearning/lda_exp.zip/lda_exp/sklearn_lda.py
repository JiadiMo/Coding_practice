# coding=utf-8
"""
此代码用于完成测试文件的主题分类
by邵麟
"""

import numpy as np
import pandas as pd
import re
from gensim import corpora, models, similarities
import gensim
import os


# 加载用于测试的文本
rootPath = "./data"
docName = os.listdir(rootPath)
# print(docName)

# 把上面目录下的txt文本（该文件已经经过分词和停用词处理了），加载到docList中，
docList = []
for name in docName:
    texts = ""
    path = os.path.join(rootPath, name)
    # print(path)
    if os.path.isfile(path) is True:
        fp = open(path, 'r', encoding='UTF-8')
        text = fp.read()
        # print("text:", text)
        docList.append(text)
        fp.close()
# print(docList)
# print(len(docList))

# 得到了docList 是['这里是一条txt文本'，'这里是一条txt文本',......]（文本已经是经过停词和分词处理了）
# 将每个txt文本分成一个个词，feed到词库中dictionary
# 得到的texts 是['这里 是一条 txt 文本'，'这里 是 一条 txt 文本',......]
texts = [[word for word in doc.split()] for doc in docList]
# 得到整个语料库的词库
dictionary = corpora.Dictionary(texts)
# 对词库进行编号处理
corpus = [dictionary.doc2bow(text) for text in texts]
# 将 '这里 是一条 txt 文本' 用 [(31, 2), (73, 1), (104, 2), (113, 1), ... 的形式表示，含义为：(词的标号, 词在本文本中出现的频率)
# print(corpus[2])
# 训练lda主题分类模型
lda = gensim.models.ldamodel.LdaModel(corpus=corpus, id2word=dictionary, num_topics=5)
# 输出结果，和，主题下的代表词
result = lda.print_topics(num_topics=5, num_words=5)
print(result)

print("finished")